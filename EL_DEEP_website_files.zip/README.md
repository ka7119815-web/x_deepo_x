# EL DEEP — Official Website

موقع ثابت باللغة العربية (RTL) بتصميم داكن وزجاجي ومتوافق مع الهاتف.

## النشر على GitHub Pages
1. فك ضغط الملف.
2. افتح مستودع GitHub الخاص بك.
3. اختر Add file ثم Upload files.
4. ارفع `index.html` و `README.md` إلى جذر المستودع (وليس داخل مجلد فرعي).
5. اضغط Commit changes.
6. افتح Settings ثم Pages.
7. من Build and deployment اختر Deploy from a branch.
8. اختر Branch: `main` و Folder: `/ (root)` ثم Save.
9. انتظر حتى يظهر رابط الموقع في صفحة Pages.

## التخصيص
- غيّر `EL DEEP` والنصوص داخل `index.html`.
- استبدل رابط `mailto:hello@example.com` برابط تواصل حقيقي عند توفره.
